PHASE 1:
        Our assembler won't accept instructions without special characters like comma,bracket,etc...

        .data and .text must be mentioned for our assembler to run.

        After compling our code first give input file .asm which contains contains assembly code and make sure that before compling there should be mcfile.mc file for writing machine code of given input file assembly code.

PHASE 2:
      expect memory allocation remaining were done.

GROUP MEMBERS-
   1.Meravath Vamsi Naik-2018csb1100- In phase1 reading and writing files, Rformat,helped in I and S formats, some other functions and connected the complete code.
In phase 2,fetch,alu,decoding immediate and id.

   2.Goroju Sanjay kumar-2018csb1091- In phase 1 UJ foramt,assembly directives,helped in doing SB format also. In phase2,Register update,decoding registers.

   3.Nikitha mourya-2018csb1110- In phase1 sb format,S format.
   4.Abhinav -2018csb1064- I format in phase 1.
  
